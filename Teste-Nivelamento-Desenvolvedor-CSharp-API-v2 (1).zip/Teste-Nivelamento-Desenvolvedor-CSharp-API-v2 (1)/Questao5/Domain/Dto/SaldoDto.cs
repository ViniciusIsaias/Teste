﻿namespace Questao5.Domain.ViewModel
{
    public class SaldoDto
    {
        public int Numero { get; set; }

        public string? Nome { get; set; }

        public DateTime DataConsulta { get; set; }

        public string Saldo { get; set; }
    }
}
