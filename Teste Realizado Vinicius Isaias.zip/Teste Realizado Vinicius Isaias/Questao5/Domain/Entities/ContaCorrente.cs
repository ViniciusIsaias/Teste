﻿namespace Questao5.Domain.Entities
{
    public class ContaCorrente
    {
        public string IdContaCorrente { get; set; }

        public int Numero { get; set; }

        public string? Nome { get; set; }

        public bool Ativo { get; set; }

        public decimal Saldo { get; set; }

        public DateTime DataConsulta { get; set; }

        public string TipoMovimento { get; set; }

        public decimal Valor { get; set; }
    }
}
